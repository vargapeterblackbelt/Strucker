package hu.elte;

import hu.elte.strucker.application.StruckerApplication;

public class Main {

    public static void main(String[] args) {
        StruckerApplication app = new StruckerApplication();
        app.run();
    }

}
