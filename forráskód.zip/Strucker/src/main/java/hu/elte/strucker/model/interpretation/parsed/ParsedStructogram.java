package hu.elte.strucker.model.interpretation.parsed;

public interface ParsedStructogram {
    void execute() throws Exception;
}
