package hu.elte.strucker.recognizer;

public interface Operation {
    Object eval() throws Exception;
}
