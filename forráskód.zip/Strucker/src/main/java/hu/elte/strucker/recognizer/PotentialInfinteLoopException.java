package hu.elte.strucker.recognizer;

public class PotentialInfinteLoopException extends Exception {
    public PotentialInfinteLoopException(String msg) {
        super(msg);
    }
}
