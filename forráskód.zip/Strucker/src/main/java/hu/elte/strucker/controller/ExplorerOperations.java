package hu.elte.strucker.controller;

public interface ExplorerOperations {
    void closeAll();
    void saveAll();
    void expand();
    void collapse();
    void open();
}
