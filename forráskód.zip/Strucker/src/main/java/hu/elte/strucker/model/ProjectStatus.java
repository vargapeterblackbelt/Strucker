package hu.elte.strucker.model;

public enum ProjectStatus {
    MODIFIED, SAVED;
}
