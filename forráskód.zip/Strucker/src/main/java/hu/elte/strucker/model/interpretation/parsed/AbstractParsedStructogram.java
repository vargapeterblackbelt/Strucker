package hu.elte.strucker.model.interpretation.parsed;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public abstract class AbstractParsedStructogram implements ParsedStructogram {

}

